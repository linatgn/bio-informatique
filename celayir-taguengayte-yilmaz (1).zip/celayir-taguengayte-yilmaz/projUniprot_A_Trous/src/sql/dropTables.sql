drop table entries_2_keywords cascade constraints;

drop table keywords cascade constraints;

drop table dbref cascade constraints;

drop table comments cascade constraints;

drop sequence seq_comment_id;

drop table entry_2_gene_name cascade constraints;


drop table gene_names cascade constraints;

drop sequence seq_gene_names;

drop table prot_name_2_prot cascade constraints;


drop sequence seq_prot_names;

drop table protein_names cascade constraints;

drop table proteins cascade constraints;

drop table entries cascade constraints;

