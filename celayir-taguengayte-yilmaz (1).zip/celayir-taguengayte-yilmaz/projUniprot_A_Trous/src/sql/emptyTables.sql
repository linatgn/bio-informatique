DELETE FROM entries_2_keywords;

DELETE FROM keywords;

DELETE FROM dbref;

DELETE FROM comments ;

DELETE FROM entry_2_gene_name ;

DELETE FROM gene_names ;

DELETE FROM prot_name_2_prot;

DELETE FROM protein_names;

DELETE FROM proteins;

DELETE FROM entries ;

COMMIT;
